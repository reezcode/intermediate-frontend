import home from "./script/view/home.js";
import './script/view/components/index.js';

document.addEventListener('DOMContentLoaded', () => {
    home();
});
